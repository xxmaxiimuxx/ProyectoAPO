package modelo;

public class Producto {
    
}
